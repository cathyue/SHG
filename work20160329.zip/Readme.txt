Major programs: 

1. ome_lp: given l,p,n, R, calculate omega;

2. detuning: given l, p, n, R, calculate (w2-w)/(w2), with figure;

3. kappa_cal��given l, p, n, R, calculate coupling coefficient without detuning.

4. NL_eq: I deduced the coupled mode equations to a pair of complex nonlinear equations. Using steady state analysis, they can be further simplified into one complex nonlinear equation -> two real nonlinear equations. (see the photo 'nonlinearCoupledModeEqs')

5. IO_nonlinear: NL_eq solver (fsolve), yields Pout